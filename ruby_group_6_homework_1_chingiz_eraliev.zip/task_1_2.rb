puts "What is your name? "
name = gets.chomp
puts "What is your famely name? "
fname = gets.chomp
puts "Date of your birthday? "
bday = gets.chomp
puts "What is your address? Please Country, city, street and number "
address = gets.chomp
puts "mr. #{fname} I just want to conferm your information"
puts "your birthday is #{bday}, and address is #{address}" 
puts "Thank you mr. #{fname} bye! "