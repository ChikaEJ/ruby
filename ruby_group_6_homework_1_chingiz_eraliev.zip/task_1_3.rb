puts "How old are you? "
age = gets.chomp
puts "What is your weight? "
weight = gets.chomp
puts "Your age is #{age} and weight is #{weight}"