class Category < ApplicationRecord
  belongs_to :shop
end
