require 'test_helper'

class FoodCotegoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
