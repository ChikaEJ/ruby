require 'test_helper'

class EquipmentControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
