require "application_system_test_case"

class NoticesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit notices_url
  #
  #   assert_selector "h1", text: "Notice"
  # end
end
