puts 'Enter number: '
number = gets.chomp.to_i
