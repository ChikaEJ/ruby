module NoticesHelper
end
