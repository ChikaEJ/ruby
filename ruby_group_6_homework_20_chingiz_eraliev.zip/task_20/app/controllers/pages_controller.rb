class PagesController < ApplicationController
  def about
  end

  def contacts
  end
end
