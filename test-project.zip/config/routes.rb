Rails.application.routes.draw do
  resources :products
end
