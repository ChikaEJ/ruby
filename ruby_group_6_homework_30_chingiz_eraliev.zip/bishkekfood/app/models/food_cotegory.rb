class FoodCotegory < ApplicationRecord
end
