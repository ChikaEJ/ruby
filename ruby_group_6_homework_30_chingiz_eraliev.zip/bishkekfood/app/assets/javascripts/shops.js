$(document).on('turbolinks:load', function () {
    $('#add_to_basket').on('click', function (event) {
        // event.preventDefault();
        var count = $('#count');

    });
});
// function addToBasket(food) {
//     var foodList = "";
//     console.log(food);
//     foodList.append('<div>'+ +'</div>');
// }