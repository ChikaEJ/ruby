require 'test_helper'

class GenerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
