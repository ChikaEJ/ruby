require 'test_helper'

class PhotographerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
