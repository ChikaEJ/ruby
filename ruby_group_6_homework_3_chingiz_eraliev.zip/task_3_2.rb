yoda = ["on Ruby", "programming ", "I like "]
puts yoda[2] + yoda[1] + yoda[0]
puts "#{yoda[2] + yoda[1] + yoda[0]}"
