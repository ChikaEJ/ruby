puts " A "
a = gets.chomp.to_i

puts " B "
b = gets.chomp.to_i

if a > b
  puts ">"
else a < b
  puts "<"
else
  puts "="  
end
