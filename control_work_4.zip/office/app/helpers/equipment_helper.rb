module EquipmentHelper

end
