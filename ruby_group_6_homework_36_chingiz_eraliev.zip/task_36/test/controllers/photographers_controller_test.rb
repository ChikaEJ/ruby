require 'test_helper'

class PhotographersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
